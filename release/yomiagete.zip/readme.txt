=== Yomiagete! ===
Contributors: Ganohr
Tags: Readout, Audiolize, TTS
Donate link: http://amzn.asia/gw9HHbg
Requires at least: 4.0
Tested up to: 6.3
Requires PHP: 5.0
Stable tag: 0.0.1
License: GPLv2
License URI: http://www.opensource.jp/gpl/gpl.ja.html

You can add a simple readout system "Yomiagete" to your WordPress articles!

== Description ==
You can add a simple readout system "Yomiagete" to your WordPress articles!

== Frequently Asked Questions == 
Q. On which devices can I read out loud?
A. It can be used with Google Chrome, Edge, and Firefox for PCs, and with the latest versions of Google Chrome and Firefox for smartphones, respectively. We are not sure about Mac and iOS, as the developer does not own them, but they are probably fine. We would be grateful for your reports on how it works.

== Screenshots ==
1. Easy to insert readout button!


== Changelog ==
0.0.1 New Release


== Upgrade Notice ==
Tested WordPress 6.3 ja
